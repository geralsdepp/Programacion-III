<?php
    include "./Clases/persona.php";
    
    class Alumno extends Persona 
    {
        private $legajo;
        private $cuatrimestre;

        function __construct($nombre, $dni, $legajo, $cuatrimestre){
            parent::__construct($nombre, $dni);
            $this->legajo = $legajo; 
            $this->cuatrimestre = $cuatrimestre;
            $this->dni = $dni;
            $this->nombre = $nombre;            
        }

        public function getLegajo() 
        {
            return $this->legajo;
        }
        public function setLegajo($legajo){
            $this->legajo = $legajo;            
        }
        public function getCuatrimestre(){
            return $this->cuatrimestre;
        }
        public function setCuatrimestre($cuatrimestre)
        {
            $this->cuatrimestre = $cuatrimestre;
        }
        public function getNombre(){
            return $this->nombre;
        }    
        public function setNombre($nombre){
            $this->nombre = $nombre;
        }            
        public function getDNI(){
            return $this->dni;
        }        
        public function setDNI($dni)
        {
            $this->dni = $dni;
        }
    }   
?>