<?php
    include "./Clases/alumno.php";

    class PersonaDAO
    {
        public $alumnos = [];
        

        public function Listar()
        {
            $alumno1 = new Alumno("Geraldine", "37171723", "235689", "1er Cuatrimestre");
            $alumno2 = new Alumno("Carla", "30171723", "235688", "1er Cuatrimestre");
            $alumno3 = new Alumno("Cecilia", "35174723", "235489", "1er Cuatrimestre");
            $alumno4 = new Alumno("Patricia", "32121724", "225689", "1er Cuatrimestre");
            $array = array($alumno1, $alumno2, $alumno3, $alumno4); 
            $alumnos = $array;
            
            return $array;
                
        }

        function Modificar($id, $nombre, $cuatrimestre)
        {

            foreach ($this->alumnos as $key => $value) {
                if ($value->key == $id) {
                    
                }   
            }
                # code...

        }

        function Guardar($nombre, $dni, $cuatrimestre){
            array_push($alumno);
        }

        function Borrar($id)
        {
            
        }
    }
    
?>