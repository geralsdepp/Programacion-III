<?php

    include "./Clases/PersonaDAO.php";
    
    if ($_SERVER["REQUEST_METHOD"] == "GET") {
        echo "Alumnos";
        $personaDAO = new PersonaDAO();
        $alumnos = $personaDAO->Listar();


        foreach ($alumnos as $key => $alumno) {
            echo "Legajo: ".$alumno->getLegajo()."DNI: ".$alumno->getDNI()."Nombre: ".$alumno->getNombre()."Cuatrimestre: ".$alumno->getCuatrimestre()."</br>";
        }
    }


    



?>