<?php
include "./clases/exception.php";
abstract class TipoPizza{
	public const Molde = 0;
	public const Piedra = 1;
}

abstract class Sabor{
	public const Muzzarella = 0;
	public const Jamon = 1;
	public const Especial = 2;
}

class Pizza	
{
	  public $id;
	  public $tipo;
	  
	  public $sabor;
	  public $cantidad;
	  public $precio;
	  public $imagen1;
	  public $imagen2;

	 function __construct($tipo,$sabor, $cantidad, $precio, $imagen1, $imagen2, $id)
	 {
		$this->id = $id;	
		$this->cantidad = $cantidad;
		$this->setTipo($tipo);
		$this->precio = $precio;
		$this->imagen1 = $imagen1;
		$this->imagen2 = $imagen2;
		$this->setSabor($sabor);
	 }

	 public function setTipo($tipo){
		switch ($tipo) {
			case 'molde':
				$this->tipo = $tipo;
				break;
			case 'piedra':
				$this->tipo = $tipo;
				break;
			default:
				MessegeException::Mostrar("El tipo no existe");
				break;
		}
	 }

	 public function setSabor($sabor){
		switch ($sabor) {
			case 'muzzarella':
				$this->sabor = Sabor::Muzzarella;
				break;
			case 'jamon':
				$this->sabor = Sabor::Jamon;
				break;
			case 'especial':
				$this->sabor = Sabor::Especial;
				break;
			default:
				MessegeException::Mostrar("El sabor no existe");
				break;
		}
	 }

	 public function getprecio()
	 {
		  return $this->precio;
	 }
  
	 public function setprecio($precio)
	 {
		 $this->precio = $precio;
	 }

	 public function getId()
	 {
		  return $this->id;
	 }
  
	 public function setIdString($id)
	 {
		 $this->idString = $id."";
	 }

	 public function setId($id)
	 {
		 $this->id = $id + 1;
	 }

	 public function Mostrar()
	 {
		 
		  return json_encode($this);
	 }
	 public function ToJson()
	 {
		  $jsonString = json_encode($this);
		  return json_decode($jsonString);
	 }

}

