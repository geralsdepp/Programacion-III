<?php

    class PizzaDAO{

        public static function Listar($path){
            $archivo;
            if (file_exists($path)) {
                $archivo = fopen($path, "r");
                $json = fgets($archivo);
    
                $lista = json_decode($json);
                
            }else{
                $archivo = fopen($path, "w");
                fwrite($archivo, "[]");
                $lista = [];
            }
            fclose($archivo);
            return $lista;
        }

        public function Modificar(){

        }

        public static function cargarPizza($obj, $path){
            $archivo = fopen($path, "w");
            $json = fgets($archivo);
            $lista = json_decode($json);
           
            if ($lista == null) {
                $lista = [];
            }

            array_push($lista, $obj);
            $json = json_encode($lista);
            fwrite($archivo, $json);
            fclose($archivo);

        }

        public static function GuardarImagen($path, $fileName, $file)
        {
            $extension = pathInfo($fileName, PATHINFO_EXTENSION); // obtiene la extencion de la foto recibida por parametro
            $name = pathInfo($fileName, PATHINFO_FILENAME); // obtiene la extencion de la foto recibida por parametro
            $ficheros  = scandir($path); 
            $actualName = $fileName;
            $contador = 1;
            while(in_array($actualName, $ficheros))
            {
                $actualName = $name."(".$contador.")".".".$extension;
                $contador++;
            }
            $file->moveTo($path."/".$actualName);
        }
        public static function guardarArchivo($archivo, $nombreArchivo){
            move_uploaded_file($archivo, $nombreArchivo);
        }

        public static function ObtenerUltimoId($path)
        {
            $id = 1;
            $jsonArray = PizzaDAO::Listar($path);
            if($jsonArray != [])
            {
                $lastElement = end($jsonArray);
                $id = $lastElement->id + 1;
            }
            
            return $id;
        }

        //Trae un objeto sin JSON mediante una key y un valor que son recibidos por parametro
        public static function BuscarUnoPorClave($tipo, $sabor, $path)
        {
            $objects = PizzaDAO::LeerArchivo($path); //Obtiene todos los objetos sin JSON
            foreach ($objects as $object) { //recorre cada uno de esos objetos                        
                if (strtolower($object->tipo) == strtolower($tipo) &&
                strtolower($object->$sabor) == strtolower($sabor)
                    )
                { // pregunta si el objeto actual en la key recibida por parametro es igual al value recibido por parametro
                    //El $object->$attrKey devuelve su valor ejemplo ($object->nombre devuelve gabriel)
                    return $object; //si pasa el if de arriba retorna el objeto entero sin JSON
                }
            }
            return null;
        }
    }
?>