<?php
    class MessegeException{
        public static function Mostrar($mensaje){
            echo "Se ha producido un error: ".$mensaje."\n";
        }
    }
?>